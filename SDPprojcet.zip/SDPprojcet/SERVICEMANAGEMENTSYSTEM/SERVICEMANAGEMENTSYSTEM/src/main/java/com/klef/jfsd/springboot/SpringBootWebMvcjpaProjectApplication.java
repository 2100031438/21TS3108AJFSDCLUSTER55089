package com.klef.jfsd.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;

@SpringBootApplication
@ComponentScan(basePackages = {"com.klef.jfsd.springboot"})
public class SpringBootWebMvcjpaProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWebMvcjpaProjectApplication.class, args);
		System.out.println("!SERVICE MANAGEMENT SYSTEM(STUDENT)ready to start.");
	}

}
